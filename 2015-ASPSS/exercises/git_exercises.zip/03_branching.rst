- Create a new branch ``development``, using ``git branch development``.
- Switch to that branch.
- Check in which branch you are using ``git branch``.
- Create a python script that prints the first 10 integers, and commit it.
- Look at the history of your repository.
- Switch to the branch ``master``, and look again at the history. What do you
  see?
