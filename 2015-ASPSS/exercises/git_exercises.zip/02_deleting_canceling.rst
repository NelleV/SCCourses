- Rename the file ``AUTHORS`` to ``CONTRIBUTORS`` using ``git mv`` and commit
your changes
- Now delete this file and commit your changes
- Use ``git log`` to see the history of the repository.
- Create a ``TODO`` file, and add it to the staging area.
- Remove this file from the staging area.
- Create a python script called power.py
- Add this to the staging area and commit it.
- Now edit it again, and add the following function to the bottom of the file:
    def square_root(x):
        return np.sqrt(x)
- Use git checkout to remove the changes you've made to this file. You can
  check what you have done using ``git status``.
