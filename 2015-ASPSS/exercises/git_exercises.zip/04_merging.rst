- Try deleting branch ``development`` using ``git branch -d development``.
  What do you see ?
- Merge the changes of branch ``development`` in ``master``.
- Try to delete the branch ``development`` once again.

